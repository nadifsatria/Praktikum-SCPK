panjang = 5;
lebar = 3;
tinggi = 6.5;
Volume = panjang*lebar*tinggi;
Luas = 2*((panjang*lebar)+(panjang*tinggi)+(lebar*tinggi));
disp('Volume = '); disp(Volume);
disp('Luas permukaan = '); disp(Luas);