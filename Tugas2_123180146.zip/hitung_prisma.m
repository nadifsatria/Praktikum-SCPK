function[Volume1,Luas1,Volume,Luas] = hitung_prisma(panjang,lebar,tinggi)
disp('Prisma segiempat');
disp('1.Kubus');
disp('2.Balok');
jenis = input('Kode Jenis  = ');
if (jenis==1)
    sisi = input('sisi = ');
    Volume1 = 6*(sisi.^2);
    Luas1 = sisi.^3;
disp('Volume = '); disp(Volume1);
disp('Luas permukaan = '); disp(Luas1);
end
if(jenis==2)
     panjang = input('panjang = ');
    lebar = input('lebar = ');
    tinggi = input('tinggi = ');
    Volume = panjang*lebar*tinggi;
    Luas = 2*((panjang*lebar)+(panjang*tinggi)+(lebar*tinggi));
disp('Volume = '); disp(Volume);
disp('Luas permukaan = '); disp(Luas);
end
if(jenis>2 || jenis<1)
    disp('kode salah');
end    
    