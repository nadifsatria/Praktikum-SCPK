x = -6:0.1:6;
y = x.^4 - 9*x.^2;
plot(x,y)
xlabel('Sumbu X'), ylabel('Sumbu Y')
title('Kurva y = x^4-9x^2')
grid on