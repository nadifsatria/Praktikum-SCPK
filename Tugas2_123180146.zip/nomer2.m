x=[-10:0.01:10];
y1=sqrt(100+(x.^2));
plot(x,y1);
grid on
hold on
y2=sqrt(100+2*(x.^2));
plot(x,y2);
y3=sqrt(100+4*(x.^2));
plot(x,y3);
y4=sqrt(100+16*(x.^2));
plot(x,y4);
legend('y1', 'y2', 'y3', 'y4')